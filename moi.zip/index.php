
<?php include 'header.php'; ?>
    <div class="container mt-5">
        <h1>Welcome, <?php echo $_SESSION['username']; ?></h1>
    </div>
    <script src="assets/js/bootstrap.bundle.min.js"></script>
</body>
</html>
